﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using RGIL.HR.AS.Common;

namespace Itools_HRActivities.vwp_HRUploadCEODesk
{
    public partial class vwp_HRUploadCEODeskUserControl : UserControl
    {
        #region Objects
        public static string ConnectionStr = ConfigurationSettings.AppSettings["IToolsConnString"].ToString();
        #endregion

        #region Page_Load
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnSubmit.CommandArgument = "Insert";
                BindGrid();
                lblMsg.Text = string.Empty;

            }

        }
        #endregion

        #region BindGrid
        public void BindGrid()
        {
            DataTable odt = GetCEODesk(6);
            gvCEOdesk.DataSource = odt;
            gvCEOdesk.DataBind();
        }
        #endregion

        #region btnSubmit_Click
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text.Trim();
            string shortDesc = txtShortDesc.Text.Trim();
            string fullDesc = txtFullDesc.Text.Trim();
            DateTime dtPostedDt = Convert.ToDateTime(txtPostedDate.Text);
            DateTime dtExpiryDt = Convert.ToDateTime(txtExpiryDate.Text);
            //string userID = "700015045";
            string userID = CommonFunctions.GetLoginUser();

            if (btnSubmit.CommandArgument == "Insert")
            {

                int newID = Convert.ToInt32(InsertCEODesk(title, shortDesc, fullDesc, dtPostedDt, dtExpiryDt, userID, 2));
                if (newID > 0)
                {
                    ResetFields();
                    lblMsg.Text = "New Orgnization update is created successfully.";

                }
                else
                {
                    lblMsg.Text = "Error in creation in a new Organization update.";
                }
            }
            else
            {
                //int ID = 0;
                int ID = Convert.ToInt32(hdnIDField.Value);
                UpdCEODesk(title, shortDesc, fullDesc, dtPostedDt, dtExpiryDt, userID, ID, 3);
                ResetFields();
                lblMsg.Text = "Organization update is updated successfully.";
            }
            BindGrid();


        }
        #endregion

        #region Insert CEODesk
        public int InsertCEODesk(string title, string shortDesc, string fullDesc, DateTime dtPostedDate, DateTime dtExpiryDate, string strUserID, int Action)
        {
            SqlConnection oConn = new SqlConnection();
            SqlCommand oSqlComm = new SqlCommand();
            int new_ID = 0;
            try
            {
                oConn.ConnectionString = ConnectionStr;
                if (oConn.State == ConnectionState.Closed)
                    oConn.Open();
                oSqlComm.Connection = oConn;
                oSqlComm.CommandType = CommandType.StoredProcedure;
                oSqlComm.CommandText = "SP_CEODesk";

                SqlParameter oPTitle = new SqlParameter();
                oPTitle.SqlDbType = SqlDbType.VarChar;
                oPTitle.ParameterName = "@Title";
                oPTitle.Value = title;
                oSqlComm.Parameters.Add(oPTitle);

                SqlParameter oPshortDesc = new SqlParameter();
                oPshortDesc.SqlDbType = SqlDbType.VarChar;
                oPshortDesc.ParameterName = "@ShortDescription";
                oPshortDesc.Value = shortDesc;
                oSqlComm.Parameters.Add(oPshortDesc);

                SqlParameter oPfullDesc = new SqlParameter();
                oPfullDesc.SqlDbType = SqlDbType.VarChar;
                oPfullDesc.ParameterName = "@FullDescription";
                oPfullDesc.Value = fullDesc;
                oSqlComm.Parameters.Add(oPfullDesc);

                SqlParameter oPpostedDate = new SqlParameter();
                oPpostedDate.SqlDbType = SqlDbType.DateTime;
                oPpostedDate.ParameterName = "@PostedDate";
                oPpostedDate.Value = dtPostedDate;
                oSqlComm.Parameters.Add(oPpostedDate);

                SqlParameter oPExpiryDate = new SqlParameter();
                oPExpiryDate.SqlDbType = SqlDbType.DateTime;
                oPExpiryDate.ParameterName = "@ExpiryDate";
                oPExpiryDate.Value = dtExpiryDate;
                oSqlComm.Parameters.Add(oPExpiryDate);

                SqlParameter oPUserID = new SqlParameter();
                oPUserID.SqlDbType = SqlDbType.VarChar;
                oPUserID.ParameterName = "@UserID";
                oPUserID.Value = strUserID;
                oSqlComm.Parameters.Add(oPUserID);

                SqlParameter oPAction = new SqlParameter();
                oPAction.SqlDbType = SqlDbType.Int;
                oPAction.ParameterName = "@Action";
                oPAction.Value = Action;
                oSqlComm.Parameters.Add(oPAction);


                new_ID = Convert.ToInt32(oSqlComm.ExecuteScalar());

            }
            catch (Exception ex)
            {
                lblMsg.Text = ex.Message;
            }
            finally
            {
                if (oConn.State == ConnectionState.Open)
                    oConn.Close();
                oSqlComm.Dispose();

            }
            return new_ID;

        }
        #endregion

        #region Update CEODesk
        public void UpdCEODesk(string title, string shortDesc, string fullDesc, DateTime dtPostedDate, DateTime dtExpiryDate, string strUserID, int ID, int Action)
        {
            SqlConnection oConn = new SqlConnection();
            SqlCommand oSqlComm = new SqlCommand();
            try
            {
                oConn.ConnectionString = ConnectionStr;
                oConn.Open();
                oSqlComm.Connection = oConn;
                oSqlComm.CommandType = CommandType.StoredProcedure;
                oSqlComm.CommandText = "SP_CEODesk";

                SqlParameter oPTitle = new SqlParameter();
                oPTitle.SqlDbType = SqlDbType.VarChar;
                oPTitle.ParameterName = "@Title";
                oPTitle.Value = title;
                oSqlComm.Parameters.Add(oPTitle);

                SqlParameter oPshortDesc = new SqlParameter();
                oPshortDesc.SqlDbType = SqlDbType.VarChar;
                oPshortDesc.ParameterName = "@ShortDescription";
                oPshortDesc.Value = shortDesc;
                oSqlComm.Parameters.Add(oPshortDesc);

                SqlParameter oPfullDesc = new SqlParameter();
                oPfullDesc.SqlDbType = SqlDbType.VarChar;
                oPfullDesc.ParameterName = "@FullDescription";
                oPfullDesc.Value = fullDesc;
                oSqlComm.Parameters.Add(oPfullDesc);

                SqlParameter oPpostedDate = new SqlParameter();
                oPpostedDate.SqlDbType = SqlDbType.DateTime;
                oPpostedDate.ParameterName = "@PostedDate";
                oPpostedDate.Value = dtPostedDate;
                oSqlComm.Parameters.Add(oPpostedDate);


                SqlParameter oPExpiryDate = new SqlParameter();
                oPExpiryDate.SqlDbType = SqlDbType.DateTime;
                oPExpiryDate.ParameterName = "@ExpiryDate";
                oPExpiryDate.Value = dtExpiryDate;
                oSqlComm.Parameters.Add(oPExpiryDate);

                SqlParameter oPUserID = new SqlParameter();
                oPUserID.SqlDbType = SqlDbType.VarChar;
                oPUserID.ParameterName = "@UserID";
                oPUserID.Value = strUserID;
                oSqlComm.Parameters.Add(oPUserID);

                SqlParameter oPAction = new SqlParameter();
                oPAction.SqlDbType = SqlDbType.Int;
                oPAction.ParameterName = "@Action";
                oPAction.Value = Action;
                oSqlComm.Parameters.Add(oPAction);

                SqlParameter oPID = new SqlParameter();
                oPID.SqlDbType = SqlDbType.Int;
                oPID.ParameterName = "@ID";
                oPID.Value = ID;
                oSqlComm.Parameters.Add(oPID);

                oSqlComm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                lblMsg.Text = ex.Message;
            }
            finally
            {
                oConn.Close();
                oSqlComm.Dispose();
            }

        }
        #endregion

        #region Get CEO Desk By ID
        public DataTable GetCEODeskByID(int ID, int Action)
        {
            DataTable dtOrgUpd = new DataTable();
            IDataReader reader = null;
            SqlConnection oConn = new SqlConnection();
            SqlCommand oSqlComm = new SqlCommand();
            try
            {
                oConn.ConnectionString = ConnectionStr;
                if (oConn.State == ConnectionState.Closed)
                    oConn.Open();
                oSqlComm.Connection = oConn;
                oSqlComm.CommandType = CommandType.StoredProcedure;
                oSqlComm.CommandText = "SP_CEODesk";


                SqlParameter oPAction = new SqlParameter("@Action", Action);
                oSqlComm.Parameters.Add(oPAction);

                SqlParameter oPID = new SqlParameter("@ID", ID);
                oSqlComm.Parameters.Add(oPID);

                reader = oSqlComm.ExecuteReader();
                dtOrgUpd.Load(reader);
            }
            catch (Exception ex)
            {
                lblMsg.Text = ex.Message;
            }
            finally
            {
                if (oConn.State == ConnectionState.Open)
                    oConn.Close();
                reader.Dispose();
                oSqlComm.Dispose();

            }
            return dtOrgUpd;
        }


        #endregion

        #region gvCEOdesk RowCommand
        protected void gvCEOdesk_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            btnSubmit.CommandArgument = "Update";

            //int index = Convert.ToInt32(e.CommandArgument);
            //GridViewRow gvRow =(GridViewRow) gvCEOdesk.Rows[index];
            //txtTitle.Text = Convert.ToString(gvRow.Cells[0].Text);
            //txtShortDesc.Text = Convert.ToString(gvRow.Cells[1].Text);
            //txtFullDesc.Text = Convert.ToString(gvRow.Cells[2].Text);
            //txtPostedDate.Text = Convert.ToString(gvRow.Cells[3].Text);
            //txtExpiryDate.Text = Convert.ToString(gvRow.Cells[4].Text);

            int id = Convert.ToInt32(e.CommandArgument);
            DataTable dt = GetCEODeskByID(id, 4);
            if (dt != null && dt.Rows.Count > 0)
            {
                txtTitle.Text = Convert.ToString(dt.Rows[0]["Title"]);
                txtShortDesc.Text = Convert.ToString(dt.Rows[0]["ShortDescription"]);
                txtFullDesc.Text = Convert.ToString(dt.Rows[0]["FullDescription"]);

                txtPostedDate.Text = FormatDt(Convert.ToDateTime(dt.Rows[0]["PostedDate"]));
                txtExpiryDate.Text = FormatDt(Convert.ToDateTime(dt.Rows[0]["ExpiryDate"]));

            }
            hdnIDField.Value = Convert.ToString(id);

        }
        #endregion

        #region Get CEODesk
        public DataTable GetCEODesk(int Action)
        {
            DataTable dtOrgUpd = new DataTable();
            IDataReader reader = null;
            SqlConnection oConn = new SqlConnection();
            SqlCommand oSqlComm = new SqlCommand();
            try
            {
                oConn.ConnectionString = ConnectionStr;
                if (oConn.State == ConnectionState.Closed)
                    oConn.Open();
                oSqlComm.Connection = oConn;
                oSqlComm.CommandType = CommandType.StoredProcedure;
                oSqlComm.CommandText = "SP_CEODesk";


                SqlParameter oPAction = new SqlParameter("@Action", Action);
                oSqlComm.Parameters.Add(oPAction);

                reader = oSqlComm.ExecuteReader();
                dtOrgUpd.Load(reader);

            }
            catch (Exception ex)
            {
                lblMsg.Text = ex.Message;
            }
            finally
            {
                if (oConn.State == ConnectionState.Open)
                    oConn.Close();
                reader.Dispose();
                oSqlComm.Dispose();

            }
            return dtOrgUpd;
        }
        #endregion

        #region gvCEOdesk RowEditing
        protected void gvCEOdesk_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvCEOdesk.EditIndex = e.NewEditIndex;
            DataTable odt = GetCEODesk(1);
            gvCEOdesk.DataSource = odt;
            gvCEOdesk.DataBind();
        }
        #endregion

        #region Format Dt
        public string FormatDt(DateTime dtDate)
        {
            return dtDate.ToString("dd-MMM-yyyy");
        }
        #endregion

        #region ResetFields
        public void ResetFields()
        {
            txtTitle.Text = string.Empty;
            txtShortDesc.Text = string.Empty;
            txtFullDesc.Text = string.Empty;
            txtPostedDate.Text = string.Empty;
            txtExpiryDate.Text = string.Empty;
            btnSubmit.CommandArgument = "Insert";
            hdnIDField.Value = string.Empty;
            lblMsg.Text = string.Empty;

        }
        #endregion

        #region btnCancel Click
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ResetFields();
        }
        #endregion
    }
}
